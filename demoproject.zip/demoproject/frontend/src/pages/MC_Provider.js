import React from 'react';

function Reports() {
  return (
    <div className='reports'>
      <h1>MC_Provider</h1>
    </div>
  );
}

export default Reports;
