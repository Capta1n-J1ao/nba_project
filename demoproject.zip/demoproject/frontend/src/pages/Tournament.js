import React from 'react';

function Reports() {
  return (
    <div className='Tournament'>
      <h1>Tournament</h1>
    </div>
  );
}

export default Reports;
