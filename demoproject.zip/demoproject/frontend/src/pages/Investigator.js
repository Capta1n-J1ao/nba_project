import React from 'react';

function Reports() {
  return (
    <div className='reports'>
      <h1>Investigator</h1>
    </div>
  );
}

export default Reports;
