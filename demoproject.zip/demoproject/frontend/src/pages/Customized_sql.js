import React from 'react';

function Reports() {
  return (
    <div className='Customized_sql'>
      <h1>Customized_sql</h1>
    </div>
  );
}

export default Reports;
