import './App.css';
import React, {useState, useEffect} from "react";
// import Axios from 'axios';
import Navbar from './components/Navbar/Navbar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Players from './pages/Players';
import Tournament from './pages/Tournament';
import My_Team from './pages/My_Team';
import Investigator from './pages/Investigator';
import MC_Provider from './pages/MC_Provider';
import Stadium from './pages/Stadium';
import Customized_sql from './pages/Customized_sql';


// start cmd:
// npm start
// Hook 
function App() {
  return (
    <>
      <Router>
        <Navbar />
        <Routes>
          <Route path='/' element={<Players/>} />
          <Route path='/My_Team' element={<My_Team/>} />
          <Route path='/Tournament' element={<Tournament/>} />
          <Route path='/Investigator' element={<Investigator/>} />
          <Route path='/MC_Provider' element={<MC_Provider/>} />
          <Route path='/Stadium' element={<Stadium/>} />
          <Route path='/Customized_sql' element={<Customized_sql/>} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
